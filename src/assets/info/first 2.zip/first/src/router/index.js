import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import test1 from '@/components/test/test1'

import headerlg from '@/components/headerlg'
import headersm from '@/components/headersm'

import singlecar from '@/components/singlecar'
import services from '@/components/services'




import carMain from '@/components/carinfo/carMain.vue'
import defaultlist from '@/components/carinfo/defaultlist.vue'

import monthpayasc from '@/components/carinfo/monthpayasc.vue'
import monthpaydsc from '@/components/carinfo/monthpaydsc.vue'

import firstpayasc from '@/components/carinfo/firstpayasc.vue'
import firstpaydsc from '@/components/carinfo/firstpaydsc.vue'

import downpayasc from '@/components/carinfo/downpayasc.vue'
import downpaydsc from '@/components/carinfo/downpaydsc.vue'

import shaixuan from '@/components/carinfo/shaixuan.vue'
import shaixuansm from '@/components/carinfo/shaixuansm.vue'




import mainpage from '@/components/mainpage.vue'

import sellCar from '@/components/sellCar.vue'

import carvideo from '@/components/carvideo.vue'

import info from '@/components/info.vue'

import contact from '@/components/contact.vue'



Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path: '/test/:price',
      name: 'test1',
      component: test1,
    },

    {
      path:'/headerlg',
      name: 'headerlg',
      component: headerlg
    },
    {
      path:'/headersm',
      name: 'headersm',
      component: headersm
    },
    
    {
      path:'/singlecar',
      name: 'singlecar',
      component: singlecar
    },

    {
      path:'/services',
      name: 'services',
      component: services
    },
    
    {
      path:'/carMain',
      name: 'carMain',
      component: carMain,
      children: [
      {
          path: '/',
          redirect:'/defaultlist',
          component: defaultlist
        },
        {
          path: '/defaultlist',
          component: defaultlist,
          name: 'defaultlist'
        },
        {
          path: '/monthpayasc',
          component: monthpayasc
        },
        {
          path: '/shaixuan',
          component: shaixuan
        },
        {
          path: '/shaixuansm',
          component: shaixuansm
        },

      {
        path: '/monthpaydsc',
        name: 'monthpaydsc',
        component: monthpaydsc
      },
      {
        path: '/firstpayasc',
        name: 'firstpayasc',
        component: firstpayasc
      },

    {
      path: '/firstpaydsc',
      name: 'firstpaydsc',
      component: firstpaydsc
    },
    {
      path: '/downpayasc',
      name: 'downpayasc',
      component: downpayasc
    },

    {
      path: '/downpaydsc',
      name: 'downpaydsc',
      component: downpaydsc
    }
    
    ]
  },

  {
    path: '/mainpage',
    name: 'mainpage',
    component: mainpage
  },
  
  {
    path: '/sellCar',
    name: 'sellCar',
    component: sellCar
  },

  {
    path: '/carvideo',
    name: 'carvideo',
    component: carvideo
  },
  {
    path: '/info',
    name: 'info',
    component: info
  },

  {
    path: '/contact',
    name: 'contact',
    component: contact
  }
  ]


})
