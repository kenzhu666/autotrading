<template>
    <div class="layout">
        <Layout>

            <headerlg v-responsive.lg.xl></headerlg>
            <headersm v-responsive.md.sm.xs></headersm>

            
            
            <Content :style="{margin: 'auto', width: '90%'}">
                
                <div v-responsive.lg.xl class = "full">
                    <Divider orientation="left">视频名称</Divider>
                    <div class = "pic2">
                    <iframe src="https://www.youtube-nocookie.com/embed/BNEQ7XG9x-Q?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    </div>
                </div>
                <div v-responsive.md.sm.xs class = "full-sm">
                    <div class = "video">
                    <p>大咖车第一期之德国猛兽甩飞女摄影师</p>
                    <div class = "pic2">
                    <iframe src="https://www.youtube-nocookie.com/embed/BNEQ7XG9x-Q?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    </div>
                    </div>
                    <Divider/>

                    <div class = "video">
                    <p>如何让皮几万的歌健康向上 ！！！【大咖车】梅赛德斯<br>AMG GTS测评</p>
                    <div class = "pic2">
                    <iframe src="https://www.youtube-nocookie.com/embed/Cl5hHQp1kMY?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    </div>
                    </div>
                    <Divider/>

                    <div class = "video">
                    <p>保时捷 911窒息测评之震撼航拍</p>
                    <div class = "pic2">
                   <iframe src="https://www.youtube-nocookie.com/embed/YuDjZmxF94M?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    </div>
                    </div>
                    <Divider/>

                    <div class = "video">
                    <p>保时捷 911窒息测评之震撼航拍</p>
                    <div class = "pic2">
                    <iframe src="https://www.youtube-nocookie.com/embed/Frah5v3-50o?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    </div>
                    </div>
                </div>
            </Content>


            


            <Footer class="layout-footer-center">2011-2016 &copy; TalkingData</Footer>

        </Layout>
    </div>        
</template>

<script>
import headerlg from '@/components/headerlg';
import headersm from '@/components/headersm';

    export default {
        components:{
            'headerlg':headerlg,
            'headersm':headersm,
        },
        
        data () {


            return {
            
            }
        }       
    }
</script>

<style scoped>

.layout{
    border: 1px solid #d7dde4;
    background: #f5f7f9;
    border-radius: 4px;

}

.full{
    margin:auto;
    margin-top:25%;
    width:80%;
}

.pic2{
    
    position:relative;
    height:0;
    padding-top:56.25%;

}
.video{
    margin-top:3%;
}

.pic2 iframe{
    position:absolute;
    left:0px;
    top:0px;
    bottom:0px;
    right:0px;
    width:100%;
    height:100%;
}

.full-sm{
    margin:auto;
    margin-top:25%;
    width:90%;
}


.layout-footer-center{
    text-align: center;
}

</style>