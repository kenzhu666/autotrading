<template>

<Content>
        <div>
                    <div class = "info">
                    <Divider orientation="left">中华汽车维修中心</Divider>
                    <p>车身维修，事故拖车，保险理赔；lease return包过，换雪胎$9起，车底防锈$49起</p><br>
                    <p>416-759-4241 / 647-598-8513</p><br>
                    <p>联系人：中华汽车维修中心</p><br>
                    <p>88 Sherry road Unit 4.Markham, ON L3T 5W5</p><br>
                    </div>

                    <Collapse class = "map">
                        <Panel name="1">
                            点击查看地图
                            <div slot="content" id = "map1" style="width: 100%"><iframe width="100%" height="300" src="https://maps.google.com/maps?width=100%&amp;height=600&amp;hl=en&amp;q=3359%20Mississauga%20Rd%2C%20Mississauga%2C%20ON%20L5L%201C6+(My%20Business%20Name)&amp;ie=UTF8&amp;t=&amp;z=14&amp;iwloc=B&amp;output=embed"><a href="https://www.maps.ie/create-google-map/"></a></iframe></div>
                        </Panel>
                    </Collapse>
        </div>
        <Divider/>

</Content>



</template>

<script>
    export default{
        data(){
            return{
                
            }
        }
    }
</script>

<style scoped>
.c1{
    margin:2%;
}

p{
    text-align:left;
}

.map{
    width:98%;
    margin:auto;
}

.info{
    width:98%;
    margin:auto;
}


</style>