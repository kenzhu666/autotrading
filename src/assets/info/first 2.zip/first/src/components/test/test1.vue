<template>
  <div class = "top">

    <ul>
        <li>
        <input type = "radio" id = "select1" value = "" v-model = "price">全选
        <input type = "radio" id = "10000" value = "10000" v-model = "price" >10000

        <input type = "radio" id = "20000" value = "20000" v-model = "price" >20000

        <input type = "radio" id = "30000" value = "30000" v-model = "price" >30000

        <input type = "radio" id = "40000" value = "40000" v-model = "price" >40000</li>

<br>

    <li>
        <input type = "radio" value = "" v-model = "brand">全选
        <input type = "radio" value = "audi" v-model = "brand">audi

        <input type = "radio" value = "benz" v-model = "brand">benz

        <input type = "radio" value = "bmw" v-model = "brand">bmw

        <input type = "radio" value = "honda" v-model = "brand">honda
        
        <input type = "radio" value = "toyota" v-model = "brand">toyota
        
        <input type = "radio" value = "lexus" v-model = "brand">lexus</li>
    </ul>

        <ul>
            <li v-for="item in list" v-bind:key="item">{{item.price}}</li>
 
        </ul>

        <p>aaaa</p>
        

    </div> 

</template>




<script>
export default{
    data() {
        return{
            selectlist:[],
            list:[
            {car:"1", information: "A5", brand: "audi", type : "中高端", price : "10000"},
            {car:"2", information: "M6", brand: "bmw", type : "性能轿跑", price : "40000"},
            {car:"3", information: "s600", brand: "benz", type : "豪华车", price : "20000"},
            {car:"4", information: "civic", brand: "honda", type : "家庭经济", price : "10000"},
            {car:"5", information: "xxx", brand: "toyota", type : "suv", price : "20000"},
            {car:"6", information: "ls250", brand: "lexus", type : "中高端", price : "30000"}],
/*
            condition: {price:"", brand: ""},
            price:'',
            brand: ''
            */
        }
    },

/*
    created(){
        this.compare(this.condition,this.list);
    },

    watch:{
        price:function(){
            this.condition.price = this.price;
            this.compare(this.condition, this.list);
        },

        brand:function(){
            this.condition.brand = this.brand;
            this.compare(this.condition, this.list);
        }
    },

        
        compare(condition, list){

            list&&list.forEach(element => {
                if(element.price == condition.price && element.brand == condition.brand){
                    console.log(JSON.parse(JSON.stringify(element)).car);
                    
                    this.seleclist.push({ID : JSON.parse(JSON.stringify(element)).car});
                }
            });
                
        },
        */
}
 
</script>


<style scoped>
ul{
    list-style-type:none;
}

li{
    display:inline-block;

}

.top{
    border: 1px solid black;
}

.display{
    border: 1px solid black;
}
</style>


