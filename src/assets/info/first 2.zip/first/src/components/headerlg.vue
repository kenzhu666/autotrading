<template>
    <Menu class = "menu" mode="horizontal" :theme="light" active-name="1">
                    <div class = "menu-logo">极车网DRIVEBEAT</div>
                    <div class = "menu-content">
                    <MenuItem name="1">
                        <Icon type="ios-paper" />
                        <router-link id = "a" to = '/mainpage'>首页</router-link>
                    </MenuItem>
                    <MenuItem name="2">
                        <Icon type="ios-people" />
                        <router-link id = "a" to = '/carMain'>我要买车</router-link>
                    </MenuItem>
                    <MenuItem name="3">
                        <Icon type="ios-paper" />
                        <router-link id = "a" to = '/sellCar'>我要卖车</router-link>
                    </MenuItem>
                    <MenuItem name="4">
                        <Icon type="ios-paper" />
                        <router-link id = "a" to = '/carvideo'>最新测评</router-link>
                    </MenuItem>
                    <MenuItem name="5">
                        <Icon type="ios-people" />
                        <router-link id = "a" to = '/services'>周边服务</router-link>
                    </MenuItem>
                    
                    </div>
                </Menu>

</template>

<script></script>

<style scoped>
.menu{
    width:100%;
    z-index: 999;
    position: fixed;
}
.menu-logo{
    float:left;
    padding-left:5%;
    font-size:2vw;
}
.menu-content{
    float:right;
    padding-right:5%;
}

a{
    color:black;
}

</style>