<template>
    <div class="layout">
        <Layout>
            <headerlg v-responsive.lg.xl></headerlg>
            <headersm v-responsive.md.sm.xs></headersm>


            <Content v-responsive.lg.xl>
             
                <Card class = "content">
                    
                        <p v-for = "item in list" v-bind:key = "item.name" v-on:click = "component = 'c'+item.id" @click = "selected(item)" :class="{active: activeName == item}">{{item.name}}</p>
                    
                    <Divider />
                    <component v-bind:is = "component"></component>
                    
                </Card>
            </Content>



            <Content v-responsive.md.sm.xs>
             
                <Card class = "content-sm">
                    
                    <p v-for = "item in list" v-bind:key = "item.name" v-on:click = "component = 'c'+item.id" @click = "selected(item)" :class="{active: activeName == item}">{{item.name}}</p>
                    
                    <Divider />

                    <component v-bind:is = "component"></component>
                    
                </Card>
            </Content>



            <Footer class="layout-footer-center">2011-2016 &copy; TalkingData</Footer>
        </Layout>
    </div>
</template>

<script>
import card1 from '@/components/card1.vue';
import card2 from '@/components/card2.vue';
import headerlg from '@/components/headerlg';
import headersm from '@/components/headersm';

export default{

    components:{
        'c1':card1,
        'c2':card2,
        'headerlg':headerlg,
        'headersm':headersm,
    },
    

    data(){
        return{
            list:[{id:'1',name: "日常保养"},
                {id:'2', name: "维修改造"},
                {id:'3', name: "汽车美容"},
                {id:'4', name: "驾照咨询"}
            ],

            
            available: true,
            component: '',
            activeName: ''
        }
    },
    
    methods:{
        selected: function(item){
            this.activeName = item;
        }
    }

    

    
}
</script>



<style scoped>

.content{
    width:90%;
    margin:auto;
    margin-top:15%;
}

.content p{
    float:left;
    text-align:center;
    width:10%;
    padding:2%;
    margin:2%;
    cursor:pointer;
    display:inline-block;
}



.content-sm{
    margin-top:60px;
    color:#515a6e;
}

.content-sm p{
    text-align:center;
    width:21%;
    padding:2%;
    margin:2%;
    cursor:pointer;
    display:inline-block;
    font-size:3vw;
    font-weight:700;
    
}

.active{
    background-color: #e37222;
    color:white;
    top:5px;
    border-radius: 5%;

}




</style>