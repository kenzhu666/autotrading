<template>
    <Content>
        <div>
                    <div class = "info">
                    <Divider orientation="left">YST AUTO</Divider>
                    <p>改车xxxxxxxxxxxxxx</p><br>
                    <p>(905) 232 1170</p><br>
                    <p>联系人：INFO@YSTTUNING.COM</p><br>
                    <p>Unit 7, 1170 Burnhamthorpe Road West Mississauga, ON, L5C 4E6</p><br>
                    </div>

                    <Collapse class = "map">
                        <Panel name="1">
                            点击查看地图
                            <div slot="content" id = "map1" style="width: 100%"><iframe width="100%" height="300" src="https://maps.google.com/maps?width=100%&amp;height=600&amp;hl=en&amp;q=3359%20Mississauga%20Rd%2C%20Mississauga%2C%20ON%20L5L%201C6+(My%20Business%20Name)&amp;ie=UTF8&amp;t=&amp;z=14&amp;iwloc=B&amp;output=embed"><a href="https://www.maps.ie/create-google-map/"></a></iframe></div>
                        </Panel>
                    </Collapse>
        </div>
        <Divider/>

</Content>

</template>

<script>
</script>

<style scoped>
.c1{
    margin:2%;
}

p{
    text-align:left;
}

.map{
    width:98%;
    margin:auto;
}

.info{
    width:98%;
    margin:auto;
}

</style>