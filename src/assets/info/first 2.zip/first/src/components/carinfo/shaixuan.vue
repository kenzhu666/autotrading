<template>
    
<Card class = "layout-shaixuan">
                    <Cascader :data="data" :style="{width: '20%'}" v-model="value1"></Cascader>
                    <br><br>
                    <div class = "layout-shaixuan-detail">
                    <Row type="flex" justify="start" class="code-row-bg">
                        <Col span="3" id = "s1">DP价格:</Col>
                        <Col span="3">全部</Col>
                        <Col span="3">0-5000</Col>
                        <Col span="3">5000-10000</Col>
                        <Col span="3">10000-15000</Col>
                        <Col span="3">15000-20000</Col>
                        <Col span="3">20000以上</Col>
                    </Row>
                    <Row type="flex" justify="start" class="code-row-bg">
                        <Col span="3">车型:</Col>
                        <Col span="3">全部</Col>
                        <Col span="3">家庭经济</Col>
                        <Col span="3">中高端</Col>
                        <Col span="3">性能轿跑</Col>
                        <Col span="3">SUV</Col>
                        <Col span="3">豪华车</Col>
                    </Row>
                    <Row type="flex" justify="start" class="code-row-bg">
                        <Col span="3">月供:</Col>
                        <Col span="3">全部</Col>
                        <Col span="3">0-250</Col>
                        <Col span="3">250-500</Col>
                        <Col span="3">500-750</Col>
                        <Col span="3">750-1000</Col>
                        <Col span="3">1000以上</Col>
                    </Row>
                    </div>
                
                </Card>
</template>

<script>
    export default{
        data(){
            return{
    
                data: [{
                    value: 'beijing',
                    label: '北京',
                    children: [
                        {
                            value: 'gugong',
                            label: '故宫'
                        },
                        {
                            value: 'tiantan',
                            label: '天坛'
                        },
                        {
                            value: 'wangfujing',
                            label: '王府井'
                        }
                    ]
                }, {
                    value: 'jiangsu',
                    label: '江苏',
                    children: [
                        {
                            value: 'nanjing',
                            label: '南京',
                            children: [
                                {
                                    value: 'fuzimiao',
                                    label: '夫子庙',
                                }
                            ]
                        },
                        {
                            value: 'suzhou',
                            label: '苏州',
                            children: [
                                {
                                    value: 'zhuozhengyuan',
                                    label: '拙政园',
                                },
                                {
                                    value: 'shizilin',
                                    label: '狮子林',
                                }
                            ]
                        }
                    ],
                }]
            }
        }
    }
</script>

<style scoped>
.layout-shaixuan{
    margin-top:60px;
    margin-bottom:1.5%;
    text-align:left;
    padding-left: 2%;
}

.layout-shaixuan-dropdown{
    float: left;
}

.layout-shaixuan-detail{
    margin-top:5%;
}

.code-row-bg{
    margin-bottom:3%;
}
</style>