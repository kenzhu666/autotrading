<template>   
            <div class = "aaa" style="min-height: 200px;">
                <Row :gutter="16">
                    <Col v-responsive.lg.xl class = "layout-carinfo-col" span="6" v-for = "item in fuc" v-bind:key = "item.id">
                        <Card>
                            <div class = "pic"></div>
                            <div class = "pic-info">
                                <Row class = "row"><span class = "h1-lg">{{item.time+item.brand}}</span></Row>
                                    <Row class = "row">
                                        <Col span = "12" id = "p">Lease首付 {{item.firstpay}}</Col>
                                        <Col span = "12" id = "p">月供 {{item.monthpay}}</Col>
                                    </Row>
                                    <Row class = "row"> 
                                    <Col span = "12" id = "p">全款买断 {{item.downpay}}</Col>
                                    </Row>
                            </div>
                        </Card>
                    </Col>



                    <Col v-responsive.md.sm.xs class = "layout-carinfo-col0-sm" span="24" v-for = "item in fuc" v-bind:key = "item.id">


                            <Row>
                            <div><Col class = "pic-sm" span = "8"></Col></div>
                            <Col class = "pic-info-sm" span = "15">
                                <Row class = "row"><span class = "h1-sm">{{item.time+item.brand}}</span></Row>
                                    <Row class = "row">
                                        <Col span = "12" id = "p-sm">Lease首付 {{item.firstpay}}</Col>
                                        <Col span = "12" id = "p-sm">月供 {{item.monthpay}}</Col>
                                    </Row>
                                    <Row class = "row">
                                    <Col span = "12" id = "p-sm">全款买断 {{item.downpay}}</Col>
                                    </Row>
                                    <Row id = "p-sm">限时折扣:$xxxx</Row>
                            </Col>
                            </Row>
                            <divider/>

                    </Col>



                </Row>
            </div>
</template>


<script>      
 export default{
        data(){
            return {
                list:[
                    {car:"1", information: "A5", time: "2018", brand: "audi", type : "中高端", monthpay : "1000", firstpay : "15000", downpay : "20000"},
                    {car:"2", information: "M6", time: "2015", brand: "bmw", type : "性能轿跑", monthpay : "800", firstpay : "236000", downpay : "40000"},
                    {car:"3", information: "s600", time: "2013", brand: "benz", type : "豪华车", monthpay : "300", firstpay : "25000", downpay : "20000"},
                    {car:"4", information: "civic", time: "2011", brand: "honda", type : "家庭经济", monthpay : "6000", firstpay : "45000", downpay : "10000"},
                    {car:"1", information: "A5", time: "2019", brand: "audi", type : "中高端", monthpay : "900", firstpay : "65000", downpay : "10000"},
                    {car:"2", information: "M6", time: "2016", brand: "bmw", type : "性能轿跑", monthpay : "1200", firstpay : "48000", downpay : "40000"},
                    {car:"3", information: "s600", time: "2017", brand: "benz", type : "豪华车", monthpay : "1500", firstpay : "33000", downpay : "20000"},
                    {car:"4", information: "civic", time: "2017", brand: "honda", type : "家庭经济", monthpay : "400", firstpay : "12000", downpay : "10000"},
                    {car:"1", information: "A5", time: "2018", brand: "audi", type : "中高端", monthpay : "850", firstpay : "5000", downpay : "10000"},
                   ]
            }
        },

         computed: {
            fuc: function() {
                this.list = this.list.sort((a,b)=>a.firstpay-b.firstpay).reverse();
                return this.list;
            }
        }
    }
</script>

<style scoped>
.layout-carinfo-col{
    margin-bottom:2%;
}

.smxs{
    padding:0;
    margin:2%;
}

.pic{
    height:0;
    padding-top:75%;
    border:1px solid black;
    font-size:1rem;
}

.pic-sm{
    padding-bottom:25%;
    border:1px solid black;
}

.pic-info{
    margin-top:3%;
    height:30%;
    text-align:left;
    padding-left:1%;
    padding-bottom: 10%;
}

.pic-info-sm{
    float:right;
    height:0;
    margin-left:1%;
    padding-bottom:25%;
    text-align:left;
}

.h1-lg{
    font-size:1.5vw;
}

.h1-sm{
    font-size:5vw;
}

#p{
    margin-top:3%;
}

#p-sm{
    font-size:3vw;
    margin-top:1.5%;
}
</style>

