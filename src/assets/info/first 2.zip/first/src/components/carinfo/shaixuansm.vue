<template>
<div class = "all">
    <div id = "drop">
        <Dropdown trigger="click">
        <a>
            品牌
            <Icon type="ios-arrow-down" color = "white"></Icon>
        </a>
        <DropdownMenu slot="list" class = "list">
            <div id = "more">
                <div id = "type">
                    <p id = "title">热门品牌</p>
                    <Row>
                        <Col id = "type-info" span = "8">Audi</Col>
                        <Col id = "type-info" span = "8">BMW</Col>
                        <Col id = "type-info" span = "8">Infiniti</Col>
                        <Col id = "type-info" span = "8">Land Rover</Col><br>
                        <Col id = "type-info" span = "8">Mercedes Benz</Col>
                    </Row>
                </div>
                <div id = "time">
                    <p id = "title">豪华品牌</p>
                    <Row>
                        <Col id = "type-info" span = "8">Auston Martin</Col>
                        <Col id = "type-info" span = "8">Bentley</Col>
                        <Col id = "type-info" span = "8">Lamborghini</Col>
                        <Col id = "type-info" span = "8">Rolls-Royce</Col><br>
                    </Row>
                </div>
            </div>
        </DropdownMenu>
    </Dropdown>
    </div>






    <div id = "drop">
        <Dropdown trigger="click">
        <a>
            价格
            <Icon type="ios-arrow-down" color = "white"></Icon>
        </a>
        <DropdownMenu slot="list" class = "list">
            <div id = "more">
                <div id = "type">
                    <p id = "title">首付</p>
                    <Row>
                        <Col id = "type-info" span = "6">全部</Col>
                        <Col id = "type-info" span = "6">0-5000</Col>
                        <Col id = "type-info" span = "6">5000-10000</Col>
                        <Col id = "type-info" span = "6">10000-15000</Col><br>
                        <Col id = "type-info" span = "6">15000-20000</Col>
                        <Col id = "type-info" span = "6">20000-25000</Col>
                        <Col id = "type-info" span = "6">25000-30000</Col>
                        <Col id = "type-info" span = "6">30000以上</Col>
                    </Row>
                </div>
                <div id = "time">
                    <p id = "title">月供</p>
                    <Row>
                        <Col id = "type-info" span = "6">全部</Col>
                        <Col id = "type-info" span = "6">0-250</Col>
                        <Col id = "type-info" span = "6">250-500</Col>
                        <Col id = "type-info" span = "6">500-750</Col><br>
                        <Col id = "type-info" span = "6">750-1000</Col>
                        <Col id = "type-info" span = "6">1000-1500</Col>
                        <Col id = "type-info" span = "6">1500以上</Col>
                    </Row>
                </div>
                <div id = "time">
                    <p id = "title">全款买断</p>
                    <Row>
                        <Col id = "type-info" span = "6">全部</Col>
                        <Col id = "type-info" span = "6">0-10000</Col>
                        <Col id = "type-info" span = "6">10000-20000</Col>
                        <Col id = "type-info" span = "6">20000-30000</Col><br>
                        <Col id = "type-info" span = "6">30000以上</Col>
                    </Row>
                </div>
            </div>
        </DropdownMenu>
    </Dropdown>
    </div>





        <div id = "drop">
        <Dropdown trigger="click">
        <a href="javascript:void(0)">
            购车方式
            <Icon type="ios-arrow-down" color = "white"></Icon>
        </a>
        <DropdownMenu slot="list" class = "list">
            <div id = "more">
                    <Row>
                        <Col id = "type-info" span = "6">全部</Col>
                        <Col id = "type-info" span = "6">Lease</Col>
                        <Col id = "type-info" span = "6">Finance</Col>
                        <Col id = "type-info" span = "6">直接买</Col>
                    </Row>
                </div>
        </DropdownMenu>
    </Dropdown>
    </div>





    <div id = "drop">
        <Dropdown trigger="click">
        <a href="javascript:void(0)">
            更多
            <Icon type="ios-arrow-down" color = "white"></Icon>
        </a>
        <DropdownMenu slot="list" class = "list">
            <div id = "more">
                <div id = "type">
                    <p id = "title">车型</p>
                    <Row>
                        <Col id = "type-info" span = "6">全部</Col>
                        <Col id = "type-info" span = "6">家庭经济</Col>
                        <Col id = "type-info" span = "6">中高端</Col>
                        <Col id = "type-info" span = "6">性能轿跑</Col><br>
                        <Col id = "type-info" span = "6">suv</Col>
                        <Col id = "type-info" span = "6">豪华车</Col>
                    </Row>
                </div>
                <div id = "time">
                    <p id = "title">期限</p>
                    <Row>
                        <Col id = "type-info" span = "8">24个月以内</Col>
                        <Col id = "type-info" span = "8">24-36个月</Col>
                        <Col id = "type-info" span = "8">36-48个月</Col>
                        <Col id = "type-info" span = "8">48-60个月</Col><br>
                        <Col id = "type-info" span = "8">60个月以上</Col>
                    </Row>
                </div>
            </div>
        </DropdownMenu>
    </Dropdown>
    </div>






        <div id = "drop">
        <Dropdown trigger="click">
        <a href="javascript:void(0)">
            排序
            <Icon type="ios-arrow-down" color = "white"></Icon>
        </a>
        <DropdownMenu slot="list" id = "droplist">
            <div id = "sort">
                    <router-link id = "a1" to = "/defaultlist">default</router-link><br>
                    <router-link id = "a1" to = "/monthpayasc">月供从低到高</router-link><br>
                    <router-link id = "a1" to = "/monthpaydsc">月供从高到低</router-link><br>
                    <router-link id = "a1" to = "/firstpayasc">首付从低到高</router-link><br>
                    <router-link id = "a1" to = "/firstpaydsc">首付从高到低</router-link><br>
                    <router-link id = "a1" to = "/downpayasc">尾款从低到高</router-link><br>
                    <router-link id = "a1" to = "/downpaydsc">尾款从高到低</router-link><br>
            </div>
        </DropdownMenu>
    </Dropdown>
    </div>

    </div>
</template>

<script>
    export default{
    data(){
        return{

        }
    }
    }
</script>

<style scoped>
.all{
    background-color:#808695;
    margin-top:20%;
    width:100%;
    z-index: 999;

}


#more{
    width:99vw;
}

#title{
    text-align:left;
    margin-left:6vw;
    margin-bottom: 1vw;
}

#type-info{
    margin-top:2%;
}

#time{
    margin: 10% 0 0 0;
}


#drop{
    width:19%;
    display:inline-block;
}

.list{
    padding-bottom:2%;
    color:#515a6e;
    font-weight:400;
}

a{
   color:white;
    font-size:2.5vw;
    font-weight:600;
}

#a1{
    color:#515a6e;
    font-weight:400;
}

</style>