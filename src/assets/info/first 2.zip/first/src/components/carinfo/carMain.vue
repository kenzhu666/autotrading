<template>
    <div class="layout">
        <Layout>
            <headerlg v-responsive.lg.xl></headerlg>
            <headersm v-responsive.md.sm.xs></headersm>
            

            <Content v-responsive.lg.xl :style="{margin: '0 auto', width: '90%'}">

                <shaixuan></shaixuan>
                
                <Card>
                    <div>
                    <p>排序</p>
                    <router-link to = "/monthpayasc">月供从低到高</router-link>
                    <router-link to = "/monthpaydsc">月供从高到低</router-link>
                    <router-link to = "/firstpayasc">首付从低到高</router-link>
                    <router-link to = "/firstpaydsc">首付从高到低</router-link>
                    <router-link to = "/downpayasc">尾款从低到高</router-link>
                    <router-link to = "/downpaydsc">尾款从高到低</router-link></div>
                    
                    <router-view></router-view>
                </Card>


            
                
            </Content>

            <Content v-responsive.md.sm.xs :style="{margin: '0 auto', width: '100%'}">

                <shaixuansm></shaixuansm>
                
                <Card>
                    <router-view></router-view>
                </Card>
                
            </Content>
            
            <Footer class="layout-footer-center">2011-2016 &copy; TalkingData</Footer>

        </Layout>
            
    </div>    
</template>


<script>
import headerlg from '@/components/headerlg';
import headersm from '@/components/headersm';

import defaultlist from '@/components/carinfo/defaultlist.vue';
import monthpayasc from '@/components/carinfo/monthpayasc.vue';
import monthpaydsc from '@/components/carinfo/monthpaydsc.vue';

import firstpayasc from '@/components/carinfo/firstpayasc.vue';
import firstpaydsc from '@/components/carinfo/firstpaydsc.vue';

import downpayasc from '@/components/carinfo/downpayasc.vue';
import downpaydsc from '@/components/carinfo/downpaydsc.vue';

import shaixuan from '@/components/carinfo/shaixuan.vue';
import shaixuansm from '@/components/carinfo/shaixuansm.vue';


    export default{

        components:{
            'headerlg':headerlg,
            'headersm':headersm,
            'shaixuan':shaixuan,
            'shaixuansm':shaixuansm,

        },

        data(){
            return{
                
            }
        }
    }
</script>


<style scoped>
    .layout{
    border: 1px solid #d7dde4;
    background: #f5f7f9;
    position: relative;
    border-radius: 4px;
    overflow: hidden;
    }

.layout-footer-center{
    text-align: center;
}


ul{
    text-align:left;
    color:purple;
}
</style>
