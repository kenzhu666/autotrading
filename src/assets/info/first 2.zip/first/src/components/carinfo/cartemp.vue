<template>   
            <div class = "aaa" style="min-height: 200px;">
                <Row :gutter="16">
                    <Col v-responsive.lg.xl class = "layout-carinfo-col" span="6" v-for = "item in list" v-bind:key = "item.id">
                        <Card>
                            <div class = "pic"></div>
                            <div class = "pic-info">
                                <Row class = "row"><span class = "h1-lg">{{item.time+item.brand}}</span></Row>
                                    <Row class = "row">
                                        <Col span = "12" id = "p">Lease首付 {{item.firstpay}}</Col>
                                        <Col span = "12" id = "p">月供 {{item.monthpay}}</Col>
                                    </Row>
                                    <Row class = "row"> 
                                    <Col span = "12" id = "p">全款买断 {{item.downpay}}</Col>
                                    </Row>
                            </div>
                        </Card>
                    </Col>



                    <Col v-responsive.md.sm.xs class = "layout-carinfo-col0-sm" span="24" v-for = "item in list" v-bind:key = "item.id">


                            <Row>
                            <div><Col class = "pic-sm" span = "8"></Col></div>
                            <Col class = "pic-info-sm" span = "15">
                                <Row class = "row"><span class = "h1-sm">{{item.time+item.brand}}</span></Row>
                                    <Row class = "row">
                                        <Col span = "12" id = "p-sm">Lease首付 {{item.firstpay}}</Col>
                                        <Col span = "12" id = "p-sm">月供 {{item.monthpay}}</Col>
                                    </Row>
                                    <Row class = "row">
                                    <Col span = "12" id = "p-sm">全款买断 {{item.downpay}}</Col>
                                    </Row>
                                    <Row id = "p-sm">限时折扣:$xxxx</Row>
                            </Col>
                            </Row>
                            <divider/>

                    </Col>



                </Row>
            </div>
</template>

<script>
     export default{


        data(){
            return {
                
            }
        }

    
    }
</script>

<style scoped>
</style>