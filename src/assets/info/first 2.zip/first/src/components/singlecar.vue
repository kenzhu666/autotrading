<template>
    <div class="layout">
        <Layout>
            <headerlg v-responsive.lg.xl></headerlg>
            <headersm v-responsive.md.sm.xs></headersm>
            
            <Content v-responsive.lg.xl>
                
                <div class = "upper">
                <Row :gutter="16">
                    <Col span = "13">
                        <div class = "carimg">
                            <div class = "carimg-sm">
                                <Carousel class = "pic-list-sm" autoplay loop>
                                    <CarouselItem>
                                        <div class="demo-carousel"><img src = "../assets/carbrand/e400.jpg"></div>
                                    </CarouselItem>
                                    <CarouselItem>
                                        <div class="demo-carousel"><img src="../assets/carbrand/e4002.jpg"></div>
                                    </CarouselItem>
                                    <CarouselItem>
                                        <div class="demo-carousel"><img src="../assets/carbrand/e4003.jpg"></div>
                                    </CarouselItem>
                                    <CarouselItem>
                                        <div class="demo-carousel"><img src="../assets/carbrand/e4004.jpg"></div>
                                    </CarouselItem>
                                </Carousel>
                            </div>
                        </div>
                        <Card class = "carscroll">
                                <img src = "../assets/carbrand/e400.jpg">
                                <img src = "../assets/carbrand/e4002.jpg">
                                <img src = "../assets/carbrand/e4003.jpg">
                        </Card>
                    </Col>

                    
                    <Col span = "11">
         
                        <Card class = "first" >
                            <p><h1>TITLE</h1></p>
                            <p><h2>折扣 xxxx</h2></p>
                            <Button>导航</Button>
                            <Button>后置镜头</Button>
                            <Button>啊啊啊</Button>
                        </Card>
                        <Card class = "second" >
                        <Divider orientation="left">Lease参考价</Divider>
                            <Row id = "second-lease">
                                <Col span = "12">Lease首付 <span>xxxx</span></Col>
                                <Col span = "12">Lease月供 <span>xxxx</span></Col>
                            </Row>
                            
                            <Row id = "second-leasetime">
                                <Col span = "12">时限 xx 月</Col>
                                <Col span = "12">xxxxx km/年</Col>
                            </Row>
                        <Divider orientation="left">全款参考价</Divider>
                            <p id = "maiduan-lg">全款买断 xxxxx</p>
                        </Card>

                            <Card class = "third">
                            <Row>
                                <Divider orientation="left">基本车况</Divider>
                                <p id = "descrip-lg">Mercedes-Benz (German: [mɛʁˈtseːdəsˌbɛnts]) is a global automobile marque and a division of the German company Daimler AG.</p>
                            </Row>
                            
                        </Card>

                        <div><Button type="warning" long>SUBMIT</Button></div>
                    </Col>

                </Row>

                </div>
                <div class = "lower">
                    <p>其他好车</p><Divider/>
                    <div class = "car-random-lg">
                    <Carousel class = "pic-list-sm" 
                        :autoplay="setting.autoplay"
                        :dots="setting.dots"
                        :radius-dot="setting.radiusDot"
                        :trigger="setting.trigger"
                        :arrow="setting.arrow">
                        <CarouselItem>
                            
                            <Card class = "random" v-for = "item in randomlist" v-bind:key = "item.id">
                                <div class = "pic"></div>
                                <div class = "pic-info">
                                    <Row class = "row"><span class = "h1-lg">{{item.time+item.brand}}</span></Row>
                                        <Row class = "row">
                                            <Col span = "12" id = "p">Lease首付 {{item.firstpay}}</Col>
                                            <Col span = "12" id = "p">月供 {{item.monthpay}}</Col>
                                        </Row>
                                        <Row class = "row"> 
                                        <Col span = "12" id = "p">全款买断 {{item.downpay}}</Col>
                                        </Row>
                                </div>
                            </Card>
                        
                        </CarouselItem>

                        <CarouselItem>
                            
                            <Card class = "random" v-for = "item in randomlist" v-bind:key = "item.id">
                                <div class = "pic"></div>
                                <div class = "pic-info">
                                    <Row class = "row"><span class = "h1-lg">{{item.time+item.brand}}</span></Row>
                                        <Row class = "row">
                                            <Col span = "12" id = "p">Lease首付 {{item.firstpay}}</Col>
                                            <Col span = "12" id = "p">月供 {{item.monthpay}}</Col>
                                        </Row>
                                        <Row class = "row"> 
                                        <Col span = "12" id = "p">全款买断 {{item.downpay}}</Col>
                                        </Row>
                                </div>
                            </Card>
                        
                        </CarouselItem>

                    </Carousel>
                </div>
                </div>
            </Content>









            <Content v-responsive.md.sm.xs>
                <div class = "upper-sm">

                <div class = "title-sm">
                <p id = "h1sm"><span id = "highlight">2018 </span>BMW X6 xDrive35i</p>
                <Divider orientation="right"><p id = "h2sm">限时折扣 <span id = "discount">xxxx</span></p></Divider>
                </div>


                <div class = "carimg-sm">
                    <Carousel class = "pic-list-sm" autoplay loop>
                        <CarouselItem>
                            <div class="demo-carousel"><img src = "../assets/carbrand/e400.jpg"></div>
                        </CarouselItem>
                        <CarouselItem>
                            <div class="demo-carousel"><img src="../assets/carbrand/e4002.jpg"></div>
                        </CarouselItem>
                        <CarouselItem>
                            <div class="demo-carousel"><img src="../assets/carbrand/e4003.jpg"></div>
                        </CarouselItem>
                        <CarouselItem>
                            <div class="demo-carousel"><img src="../assets/carbrand/e4004.jpg"></div>
                        </CarouselItem>
                    </Carousel>
                </div>
            
                    
                        <Card class = "priceInfo-sm" >
                            <Divider orientation="left" id = "line">Lease参考价</Divider>
                            <Row id = "price" type="flex" justify="space-between"  class="code-row-bg">
                                <Col span = "6">首付</Col>
                                <Col span = "6">月供</Col>
                                <Col span = "6">时限</Col>
                                <Col span = "6">公里数</Col>
                            </Row>
                                
                            <Row id = "price" type="flex" justify="space-between"  class="code-row-bg">
                                <Col span = "6" class = "price-top">$10000</Col>
                                <Col span = "6" class = "price-top">$699</Col>
                                <Col span = "6" class = "price-top">36个月</Col>
                                <Col span = "6" class = "price-top">12000公里</Col>

                            </Row>
                            <Divider />
                            <Divider orientation="left" id = "line">全款参考价</Divider>
                                <Row id = "price" type="flex" justify="space-between"  class="code-row-bg">
                                <Col span = "6" class = "price-top">$39999</Col></Row>
                        </Card>
                    
                
         
                        <Card class = "hconfig-sm">
                            <Divider orientation="left" id = "line">亮点配置</Divider>
                            <Button>导航</Button>
                            <Button>后置镜头</Button>
                            <Button>啊啊啊</Button>
                        </Card>
                        

                        <Card class = "bconfig-sm">
                            <Row>
                                <Divider orientation="left" id = "line">基本信息</Divider>
                                <Row id = "price" type="flex" justify="space-between"  class="code-row-bg">
                                <p>asdasdadasdas</p>
                            </Row>
                            </Row>
                        </Card>

                </Row>



            <div class = "car-random-sm">
                    <Carousel class = "pic-list-sm" autoplay loop>
                        <CarouselItem v-for = "item in randomlist" v-bind:key = "item.id">
                        
                            <Card>
                                <div class = "pic"><img v-bind:src = item.carsrc></div>
                                <div class = "pic-info">
                                    <Row class = "row"><span class = "h1-sm-2">{{item.time+item.brand}}</span></Row>
                                        <Row class = "row">
                                            <Col span = "12" id = "p">Lease首付 <span class = "pricenum">{{item.firstpay}}</span></Col>
                                            <Col span = "12" id = "p">月供 <span class = "pricenum">{{item.monthpay}}</span></Col>
                                        </Row>

                                        <Row class = "row"> 
                                        <Col span = "12" id = "p">全款买断 <span class = "pricenum">{{item.downpay}}</span></Col>
                                        </Row>
            
                                </div>
                            </Card>
                        
                        
                        </CarouselItem>
                    </Carousel>
                </div>



            
            </div>

            </Content>

            <Footer v-responsive.lg.xl class="layout-footer-center">2011-2016 &copy; TalkingData</Footer>
            <div v-responsive.md.sm.xs class = "submit">
                    <Button class = "submit-b">点击联系小客服</Button>                
            </div>

        </Layout>
    </div>

</template>


<script>
import headerlg from '@/components/headerlg';
import headersm from '@/components/headersm';

    export default{
        name: 'Marquee',

        components:{
            'headerlg':headerlg,
            'headersm':headersm,
        },
        
        data(){
            return{
                lists:[
                    {car:"1", information: "A5", time: "2018", brand: "audi", type : "中高端", monthpay : "1000", firstpay : "15000", downpay : "20000"},
                    {car:"2", information: "M6", time: "2015", brand: "bmw", type : "性能轿跑", monthpay : "800", firstpay : "26000", downpay : "40000"},
                    {car:"3", information: "s600", time: "2013", brand: "benz", type : "豪华车", monthpay : "300", firstpay : "25000", downpay : "20000"},
                    {car:"4", information: "civic", time: "2011", brand: "honda", type : "家庭经济", monthpay : "6000", firstpay : "45000", downpay : "10000"},
                    {car:"1", information: "A5", time: "2019", brand: "audi", type : "中高端", monthpay : "900", firstpay : "65000", downpay : "10000"},
                    {car:"2", information: "M6", time: "2016", brand: "bmw", type : "性能轿跑", monthpay : "1200", firstpay : "48000", downpay : "40000"},
                    {car:"3", information: "s600", time: "2017", brand: "benz", type : "豪华车", monthpay : "1500", firstpay : "33000", downpay : "20000"},
                    {car:"4", information: "civic", time: "2017", brand: "honda", type : "家庭经济", monthpay : "400", firstpay : "12000", downpay : "10000"},
                    {car:"1", information: "A5", time: "2018", brand: "audi", type : "中高端", monthpay : "850", firstpay : "5000", downpay : "10000"},
                   ],

                randomlist:[ {car:"1", information: "A5", time: "2018", brand: "audi", type : "中高端", monthpay : "1000", firstpay : "15000", downpay : "20000", carsrc: require("../assets/sell/330i.jpg")},
                    {car:"2", information: "M6", time: "2015", brand: "bmw", type : "性能轿跑", monthpay : "800", firstpay : "236000", downpay : "40000", carsrc : require("../assets/sell/430.jpg")},
                    {car:"3", information: "s600", time: "2013", brand: "benz", type : "豪华车", monthpay : "300", firstpay : "25000", downpay : "20000", carsrc : require("../assets/sell/x1.jpg")},
                    {car:"4", information: "civic", time: "2011", brand: "honda", type : "家庭经济", monthpay : "6000", firstpay : "45000", downpay : "10000", carsrc : require("../assets/sell/x2.jpg")}],

                setting: {
                    autoplay: false,
                    dots: 'none',
                    radiusDot: false,
                    trigger: 'click',
                    arrow: 'always'
                },

                
                text:''
            }
        },

        methods: {
            move () {
        // 获取文字text 的计算后宽度  （由于overflow的存在，直接获取不到，需要独立的node计算）
            let width = document.getElementById('node1').getBoundingClientRect().width 
            let box = document.getElementById('box')
            let copy = document.getElementById('copy')
            copy.innerText = this.text // 文字副本填充
            let distance = 0 // 位移距离
        //设置位移
            setInterval(function () { 
                distance = distance - 1
        // 如果位移超过文字宽度，则回到起点
                if (-distance >= width) {
                distance = 1600
                }
                box.style.transform = 'translateX(' + distance + 'px)'
            }, 2000) 
            }
        },
        // 把父组件传入的arr转化成字符串
        mounted: function () {
            for (let i = 0; i < this.lists.length; i++) {
            this.text += ' ' + this.lists[i]
            }
        },
        // 更新的时候运动
        updated: function () {
            this.move()
        }

    }
</script>



<style scoped>
.layout{
    border: 1px solid #d7dde4;
    background: #f5f7f9;
    position: relative;
    border-radius: 4px;
    overflow: hidden;
}

.layout-footer-center{
    text-align: center;
}

.upper{
    width:90%;
    margin:auto;
    margin-top:15%;
    height:0;
    padding-bottom: 50%;
}

.carimg{
    height:0;
    padding-bottom: 75%;

}

.carscroll{
    height:0;
    padding-bottom: 30%;
}


.carscroll img{
    border:1px solid black;
    width:30%;
    display:inline-block;
    margin-right:2%;
    height:0;
    padding-bottom:25%;
}

.first{
    height:0;
    padding-bottom: 38%;
    text-align:left;
    margin-bottom:2%;
}
.first p{
    margin-top:0;
    margin-bottom: 2%;
}
.second{
    height:0;
    padding-bottom: 50%;
    text-align:left;
    margin-bottom: 2%;
}

#second-lease{
    margin:5% 0 5% 6%;

}

#second-leasetime{
    margin:5% 0 8% 6%;
}

#maiduan-lg{
    margin:5% 0 0 6%;
}

.third{
    height:0;
    padding-bottom: 22%;
    text-align:left;
    margin-bottom:3%;
}

#descrip-lg{
    margin-left: 6%;
}





.submit{
    width:100%;
    float:right;
    margin-top:8%;
}

.lower{
    width:90%;
    margin:auto;
}

.lower p{
    margin-top:5%;
    text-align:left;
}

.car-random-lg{
    width:100%;
    margin:auto;
    height:0;
    padding-bottom:25%;

    z-index: 999;
}

.random{
    width:20%;
    display:inline-block;
    float:left;

}




/*small screen */


.carimg-sm{
    width:100%;
    height:0;
    padding-bottom: 75%;
}

.upper-sm{
    margin-top:20%;
}

.title-sm{
    width:90%;
    margin:auto;
}

#h1sm{
    font-size:5vw;
    text-align:left;
    font-weight:800;
}

#h2sm{
    font-size:4vw;
    color:#ed4014;
    font-weight:700;
}

#highlight{
    color:#e37222;
}


#price{
    margin:auto;
    width:95%;
}

.price-top{
    color:#e37222;
}

.priceInfo-sm{
    margin-top:2%;
    height:0;
    padding-bottom: 65%;
    text-align:left;
}

#price{
    padding-bottom:2%;
}


.hconfig-sm{
    margin-top:2%;
    text-align:left;
    padding-bottom:15%;
}

.bconfig-sm{
    margin-top:2%;
    text-align:left;
}


.pic-list-sm{
    width:100%;
    height:0;
    padding-bottom:75%;
}

.demo-carousel{
    position:relative;
    width:100%;
    height:0;
    padding-bottom:100%;
}

.demo-carousel img{
    position:absolute;
    left:0px;
    top:0px;
    bottom:0px;
    right:0px;
    width:100%;
    height:75%;
}





.layout-carinfo-col{
    margin-bottom:2%;
    width:75vw;
}
.pic-info{
    margin-top:3%;
    height:30%;
    text-align:left;
    padding-left:1%;
    padding-bottom: 10%;
}

.pic{
    position:relative;
    height:0;
    padding-top:75%;
    font-size:1rem;
}


.pic img{
    position:absolute;
    left:0px;
    top:0px;
    bottom:0px;
    right:0px;
    width:100%;
    height:100%;
}

#p{
    margin-top:5%;
    font-size:3vw;
    font-weight:500;
}

.h1-sm-2{
    font-size:3vw;
    font-weight:600;
    color:black;
}

.pricenum{
    color:#e37222;
}


.car-random-sm{
    margin-top:2%;
    width:100%;
    height:0;
    padding-bottom: 110%;
    margin-bottom:65px;
}

.submit{
    position:fixed;
    bottom:0;
    height:60px;
    z-index:999;
}
.submit-b{
    width:100%;
    height:60px;
    font-size:5vw;
    color:white;
    font-weight:900;
    background-color:#e37222;

}



</style>