<template>
    <div class="layout">
        <Layout>

            <headerlg v-responsive.lg.xl></headerlg>
            <headersm v-responsive.md.sm.xs></headersm>

            
            
            <Content v-responsive.lg.xl :style="{margin: 'auto', width: '90%'}">
                <div class = "pic">
                    <a href = "https://www.wjx.top/m/28293236.aspx"><Button id = "b">填写问卷</Button></a>
                </div>
            </Content>

            <Content v-responsive.md.sm.xs>
                <div class = "pic-sm">
                    <a href = "https://www.wjx.top/m/28293236.aspx"><Button id = "b-sm">填写问卷</Button></a>
                </div>
            </Content>



            <Footer class="layout-footer-center">2011-2016 &copy; TalkingData</Footer>

        </Layout>
    </div>        
</template>

<script>
import headerlg from '@/components/headerlg';
import headersm from '@/components/headersm';

    export default {
        components:{
            'headerlg':headerlg,
            'headersm':headersm,
        },
        
        data () {


            return {
            
            }
        }       
    }
</script>

<style scoped>

.layout{
    border: 1px solid #d7dde4;
    background: #f5f7f9;
    position: relative;
    border-radius: 4px;
    overflow: hidden;
}

.pic{
    margin:auto;
    margin-top:100px;
    width:80%;
    height:0;
    padding-bottom:40.5%;
    border:1px solid black;
}

#b{
    width:20%;
    margin-top:40%;
    height: 4vw;
    background-color:#e37222;
    color:white;
    font-size:1.5vw;
}

.pic-sm{
    margin:auto;
    margin-top:15%;
    width:90%;
    height:0;
    padding-bottom:56.25%;
    border:1px solid black;
}

#b-sm{
    width:20%;
    margin-top:50%;
    height: 4vw;
    background-color:#f77722;
    color:white;
    font-size:1.5vw;
}



.layout-footer-center{
    text-align: center;
}

</style>