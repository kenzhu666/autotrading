<template>
    <div class="layout">
        <Layout>

            <headerlg v-responsive.lg.xl></headerlg>
            <headersm v-responsive.md.sm.xs></headersm>

            
            
            <Content :style="{margin: 'auto', width: '90%'}">
                
                <div v-responsive.lg.xl class = "full">
                    <Divider orientation="left">视频名称</Divider>
                    <div class = "pic"></div>
                </div>
                <div v-responsive.md.sm.xs class = "full-sm">
                    <Divider orientation="left">推文标题</Divider>
                    <div class = "pic"><img src="../assets/info/1.jpeg"></div>
                </div>
                <a href = "https://mp.weixin.qq.com/s?src=11&timestamp=1537731306&ver=1140&signature=GyhLSwZ3fU8yLp45Gam*tEez3PG1UNT2vXwQEiehSXcmQCpNKS2BRImefrREUausS4d1*Gm-LiQYA1iT3eWHHDnf-FfowQAXu9U7NNgJPbKQH2mcyXjpgO4UW4gSut*E&new=1">
                <Button :style="{float:'right'}" :size="buttonSize" type="text" id = "b" >
                    查看详细内容
                    <Icon type="ios-arrow-forward"/>
                </Button></a>
                <Divider/>

                <div v-responsive.lg.xl class = "full">
                    <Divider orientation="left">视频名称</Divider>
                    <div class = "pic"></div>
                </div>
                <div v-responsive.md.sm.xs class = "full-sm">
                    <Divider orientation="left">推文标题</Divider>
                    <div class = "pic"><img src="../assets/info/2.jpeg"></div>
                </div>
                <a href = "https://mp.weixin.qq.com/s?src=11&timestamp=1537731306&ver=1140&signature=GyhLSwZ3fU8yLp45Gam*tEez3PG1UNT2vXwQEiehSXcIlh*1jQ1Q1jNOEUaaBq2GGWy*2xoj5iKYrKjYbF2t40dHJxUHE3-RAQq8DFuaRHeIKYaUr0xbPmxq2-MSWxov&new=1">
                <Button :style="{float:'right'}" :size="buttonSize" type="text" id = "b" >
                    查看详细内容
                    <Icon type="ios-arrow-forward"/>
                </Button></a>
            
            
            </Content>


            


            <Footer class="layout-footer-center">2011-2016 &copy; TalkingData</Footer>

        </Layout>
    </div>        
</template>

<script>
import headerlg from '@/components/headerlg';
import headersm from '@/components/headersm';

    export default {
        components:{
            'headerlg':headerlg,
            'headersm':headersm,
        },
        
        data () {


            return {
            
            }
        }       
    }
</script>

<style scoped>

.layout{
    border: 1px solid #d7dde4;
    background: #f5f7f9;
    border-radius: 4px;

}

.full{
    margin:auto;
    margin-top:25%;
    width:80%;
}

.pic{
    margin:auto;
    width:100%;
    height:0;
    padding-bottom:56.25%;

}

.full-sm{
    margin:auto;

    width:90%;
}


.layout-footer-center{
    text-align: center;
}

#b{
    margin-top:3%;
}
img{
    width:100%;
}
</style>