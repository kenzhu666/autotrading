<template>
   <Menu class = "menu-sm" mode="horizontal" :theme="light" active-name="1">
                    <div class = "menu-logo-sm"><i>极车网</i><div id = "url"><i>www.drivebeat.com</i></div></div>
                    <div class = "menu-content-sm">
                        <div class="sildebar">
                            <div class="home" @click="hideMenu">
                            <Icon id = "icon" type="ios-menu" size = "48" color = "#808695"/>
                        </div>
                            <div class="menu" v-show="isShows" @click="hideMenu"></div>
                    
                            <transition name="slide-fade">
                                <div class="sss" v-show="isShow">
                                    <div id="left"><router-link id = "a" to = '/mainpage'><Icon type="ios-apps" id = "i"/>首页</router-link></div>
                                    <div id="left"><router-link id = "a" to = '/carMain'><Icon type="ios-car" id = "i"/>我要买车</router-link></div>
                                    <div id="left"><router-link id = "a" to = '/sellCar'><Icon type="logo-usd" id = "i"/>我要卖车</router-link></div>
                                    <div id="left"><router-link id = "a" to = '/carvideo'><Icon type="ios-podium" id = "i"/>最新测评</router-link></div>
                                    <div id="left"><router-link id = "a" to = '/info'><Icon type="ios-information-circle" id = "i"/>新车资讯</router-link></div>
                                    <div id="left"><router-link id = "a" to = '/services'><Icon type="ios-build" id = "i"/>周边服务</router-link></div>
                                    <div id="left"><router-link id = "a" to = '/contact'><Icon type="ios-contact" id = "i"/>联系我们</router-link></div>
                                </div>
                            </transition>
                        </div>
                    </div>
                    

                    
    </Menu>


</template>

<script>
export default {
		data () {
			return {
				isShow: false,
				isShows: false
			}
		},
		methods: {
			hideMenu () {
				if (this.isShow) {
					this.isShow = false
					this.isShows = false
				} else {
					this.isShow = true
					this.isShows = true
				}
				
			},
		}
	}

</script>

<style scoped>
.menu-sm{
    width:100%;
    height:0;
    padding-bottom:15%;
    z-index: 999;
    position: fixed;
    color:#515a6e;
}
.menu-logo-sm{
    float:left;
    padding-left:5%;
    font-size:7vw;
    color:#e37222;
    margin-top:1vw;
    font-weight:900;
    height:0;
    padding-bottom:13%;
}
#url{
   margin-top:-8vw;
    font-size:2vw;
    margin-left:3%;
}

#icon{
    margin-top:3vw;
}
.menu-content-sm{
    float:right;
    padding-right:5%;
}

a{
    color:black;
}



.sss{
	position: fixed;
    width: 286px;
    height: 100%;
    top: 0;
    right: 0;
    bottom: 0;
    z-index: 11;
    overflow-y: auto;
    background-color: #f8f8f9;
    font-size:4vw;
    font-weight:600;


	}
	.slide-fade-enter-active {
	  transition: all .3s ease;
	}
	.slide-fade-leave-active {
	  transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);
	}
	.slide-fade-leave-to,.slide-fade-enter{
	  transform: translateX(286px);
	  opacity: 0;
	}
	.menu {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    opacity: 1;
    z-index: 10;
    background: rgba(0,0,0,0.5);
    }

    #left{
        padding-left:5%;
        width:100%;
        height:0;
        padding-bottom:20%;
        border-bottom:1px solid #DEDEDE;
        text-align:left;
        font-size: 5vw;
    }

    a{
        color:#515a6e;
        font-size:3vw;
        font-weight:600;
    }

    a #i{
        margin-right:5%;
    }

  
</style>