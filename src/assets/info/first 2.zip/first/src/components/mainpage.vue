<template>
    <div class="layout">
        <Layout>

            <headerlg v-responsive.lg.xl></headerlg>
            <headersm v-responsive.md.sm.xs></headersm>

            
            
            <Content :style="{margin: 'auto', width: '90%'}">
                <div class = "content">
                <Carousel autoplay v-model="value2" loop>
                    <CarouselItem>
                        <div class="demo-carousel"><img src = "../assets/wallpaper/1.jpg"></div>
                    </CarouselItem>
                    <CarouselItem>
                        <div class="demo-carousel"><img src = "../assets/wallpaper/2.jpg"></div>
                    </CarouselItem>
                    <CarouselItem>
                        <div class="demo-carousel"><img src = "../assets/wallpaper/3.jpg"></div>
                    </CarouselItem>
                    <CarouselItem>
                        <div class="demo-carousel"><img src = "../assets/wallpaper/4.jpg"></div>
                    </CarouselItem>
                </Carousel>
                </div>


                <div v-responsive.lg.xl>
                    <Divider orientation="left">关于我们</Divider>
                    <Col span = "12"><Card class = "card1">视频</Card></Col>
                    <Col span = "12"><Card class = "card1">介绍</Card></Col>
                </div>
                <div v-responsive.md.sm.xs>
                    <Divider orientation="left">关于我们</Divider>
                    <i>华人汽车资讯一站式服务，加拿大第一家华人豪车测评</i>
                </div>
                <br>




                <div v-responsive.lg.xl>
                <Divider orientation="left">热销车型</Divider>
                <Row>
                    <Col span = "12"><Card :bordered="false" dis-hover class = "card2"><img src="../assets/carbrand/bmw4.png"></Card></Col>
                    <Col span = "12"><Card :bordered="false" dis-hover class = "card2"><img src="../assets/carbrand/c300.jpg"></Card></Col>
                </Row>
                <Row>
                    <Col span = "12"><Card :bordered="false" dis-hover class = "card2"></Card></Col>
                    <Col span = "12"><Card :bordered="false" dis-hover class = "card2"></Card></Col>
                </Row>
                </div>

                <div v-responsive.md.sm.xs>
                <Divider orientation="left">热销车型</Divider>
                <Row>
                    <Col span = "24"><Card class = "card2"><img src="../assets/carbrand/440.jpg"></Card></Col>
                    <Col span = "24"><Card class = "card2"><img src="../assets/carbrand/c300.jpg"></Card></Col>
                </Row>
                <Row>
                    <Col span = "24"><Card class = "card2"><img src="../assets/carbrand/x4.jpg"></Card></Col>
                    <Col span = "24"><Card class = "card2"><img src="../assets/carbrand/a4.jpg"></Card></Col>
                </Row>
                </div>

                
                
                <div v-responsive.lg.xl>
                <Divider orientation="left">折扣车型</Divider>
                <Row>
                    <Col span = "6"><Card :bordered="false" dis-hover class = "card3">1</Card></Col>
                    <Col span = "6"><Card :bordered="false" dis-hover class = "card3">2</Card></Col>
                    <Col span = "6"><Card :bordered="false" dis-hover class = "card3">3</Card></Col>
                    <Col span = "6"><Card :bordered="false" dis-hover class = "card3">4</Card></Col>
                </Row>
                <router-link id = "a" to = '/carMain'>
                <Button :style="{float:'right'}" :size="buttonSize" type="text" >
                    更多折扣
                    <Icon type="ios-arrow-forward"/>
                </Button>
                </router-link>
                </div>


                <div v-responsive.md.sm.xs>
                <Divider orientation="left">折扣车型</Divider>
                <Row>
                    <Col span = "24">
                    <div class = "card3" v-for = "item in lists" v-bind:key = "item.id">
                            <Card>
                                <div><img v-bind:src = item.carsrc></div>
                                <div class = "pic-info">
                                    <Row class = "row"><span class = "h1-sm">{{item.time+item.brand}}</span></Row>
                                        <Row class = "row">
                                            <Col span = "12" id = "p">Lease首付 <span id = "price">{{item.firstpay}}</span></Col>
                                            <Col span = "12" id = "p">月供 <span id = "price">{{item.monthpay}}</span></Col>
                                        </Row>

                                        <Row class = "row"> 
                                        <Col span = "12" id = "p">全款买断 <span id = "price">{{item.downpay}}</span></Col>
                                        </Row>
            
                                </div>
                            </Card>
                            </div>
                        </Col>
                </Row>
                <router-link id = "a" to = '/carMain'>
                <Button :style="{float:'right'}" :size="buttonSize" type="text" >
                    更多折扣
                    <Icon type="ios-arrow-forward"/>
                </Button>
                </router-link>
                </div>

                
                
               <div v-responsive.lg.xl  class = "card4">

                    <Divider orientation="left">最新测评</Divider>
                    <div class = "pic2"></div>
                </div>
                <div v-responsive.md.sm.xs class = "card4">
                    <Divider orientation="left">最新测评</Divider>
                    <div class = "pic2">
                    <iframe src="https://www.youtube-nocookie.com/embed/BNEQ7XG9x-Q?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    </div>
                </div>
                <router-link id = "a" to = '/carvideo'>
                <Button :style="{float:'right'}" :size="buttonSize" type="text" >
                    更多视频
                    <Icon type="ios-arrow-forward"/>
                </Button></router-link>

               


                <div v-responsive.lg.xl>
                <Divider orientation="left">汽车百科</Divider>
                <Row>
                    <Col span = "6"><Card :bordered="false" dis-hover class = "card4">图片</Card></Col>
                    <Col span = "18"><div>description</div></Col>                  
                </Row>
                </div>
                <div v-responsive.md.sm.xs class = "card4">
                    <Divider orientation="left">推文title</Divider>
                    <div class = "pic2"><img src="../assets/info/1.jpeg"></div>
                </div>
                <router-link id = "a" to = '/info'>
                <Button :style="{float:'right'}" :size="buttonSize" type="text" >
                    更多推文
                    <Icon type="ios-arrow-forward"/>
                </Button></router-link>
                
                
                
                <Divider orientation="left">周边服务</Divider>
                <Row>
                    <Col span = "6"><Card :bordered="false" dis-hover class = "card5">1</Card></Col>
                    <Col span = "6"><Card :bordered="false" dis-hover class = "card5">2</Card></Col>
                    <Col span = "6"><Card :bordered="false" dis-hover class = "card5">1</Card></Col>
                    <Col span = "6"><Card :bordered="false" dis-hover class = "card5">2</Card></Col>
                </Row>
                <router-link id = "a" to = '/services'>
                <Button :style="{float:'right'}" :size="buttonSize" type="text" >
                    更多服务
                    <Icon type="ios-arrow-forward"/>
                </Button></router-link>
            </Content>
            
            
            
            <Footer class="layout-footer-center">2011-2016 &copy; TalkingData</Footer>
            <br>
        </Layout>
    </div>    

    
</template>


<script>
import headerlg from '@/components/headerlg';
import headersm from '@/components/headersm';

    export default {
        components:{
            'headerlg':headerlg,
            'headersm':headersm,
        },
        
        data () {


            return {
                lists:[ {car:"1", information: "A5", time: "2018", brand: "audi", type : "中高端", monthpay : "1000", firstpay : "15000", downpay : "20000", carsrc: require("../assets/sell/330i.jpg")},
                    {car:"2", information: "M6", time: "2015", brand: "bmw", type : "性能轿跑", monthpay : "800", firstpay : "236000", downpay : "40000", carsrc : require("../assets/sell/430.jpg")},
                    {car:"3", information: "s600", time: "2013", brand: "benz", type : "豪华车", monthpay : "300", firstpay : "25000", downpay : "20000", carsrc : require("../assets/sell/x1.jpg")},
                    {car:"4", information: "civic", time: "2011", brand: "honda", type : "家庭经济", monthpay : "6000", firstpay : "45000", downpay : "10000", carsrc : require("../assets/sell/x2.jpg")}],
            }
        }       
    }
</script>

<style scoped>

.layout-footer-center{
    text-align: center;
}






.content{
    margin-top:16.7%;
    border: 1px solid black;
    margin-bottom: 2%;
}

.demo-carousel{
    height:0;
    padding-bottom:56.25%;
}

.card1{
    padding-bottom: 56.25%;
    height:0;
    margin: 3%;
}

.card2{
    padding-bottom: 75%;
    height:0;
    margin: 3%;
}


.card3{
    padding-bottom: 100%;
    height:0;
    margin: 3%;
    margin-top:5%;
}

.card4{
    padding-bottom: 56.25%;
    height:0;
    margin: 3%;
}

.card5{
    padding-bottom: 75%;
    height:0;
    margin: 3%;
}

img{
   max-width:100%;
}




/*折扣车型*/

.pic-info{
    margin-top:3%;
    height:30%;
    text-align:left;
    padding-left:1%;
    padding-bottom: 10%;
}
.pic{
    position:relative;
    height:0;
    padding-top:75%;
    font-size:1rem;
}


.pic img{
    position:absolute;
    left:0px;
    top:0px;
    bottom:0px;
    right:0px;
    width:100%;
    height:100%;
}

#p{
    margin-top:5%;
    font-size:3vw;
    font-weight:500;
}

.h1-sm{
    font-size:3vw;
    font-weight:600;
    color:black;
}

#price{
    color:#e37222;
}






/* 最新测评 */
.full{
    margin:auto;
    width:80%;
    
}

.pic2{
    
    position:relative;
    height:0;
    padding-top:56.25%;

}

.pic2 iframe{
    position:absolute;
    left:0px;
    top:0px;
    bottom:0px;
    right:0px;
    width:100%;
    height:100%;
}

.pic2 img{
    position:absolute;
    left:0px;
    top:0px;
    bottom:0px;
    right:0px;
    width:100%;
    height:100%;
}

.card4{
    margin:auto;
    margin-top:15%;
    width:95%;
    height:0;
    padding-bottom:68%;
}

</style>
